package com.amd.px;

import java.io.BufferedInputStream;
import java.io.BufferedOutputStream;
import java.io.Closeable;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.InputStream;
import java.io.OutputStream;
import java.net.URLConnection;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.nio.file.StandardCopyOption;
import java.time.LocalDate;
import java.util.Iterator;
import java.util.zip.ZipEntry;
import java.util.zip.ZipInputStream;

import org.apache.commons.compress.compressors.FileNameUtil;
//import org.apache.poi.hslf.usermodel.HSLFSlideShow;
import org.apache.poi.hssf.usermodel.HSSFObjectData;
import org.apache.poi.hssf.usermodel.HSSFWorkbook;
import org.apache.poi.hwpf.HWPFDocument;
import org.apache.poi.openxml4j.opc.ContentTypes;
import org.apache.poi.openxml4j.opc.OPCPackage;
import org.apache.poi.openxml4j.opc.PackagePart;
import org.apache.poi.openxml4j.opc.internal.ContentType;
import org.apache.poi.poifs.filesystem.DirectoryNode;
import org.apache.poi.ss.usermodel.Workbook;
import org.apache.poi.util.IOUtils;
import org.apache.poi.xslf.usermodel.XMLSlideShow;
//import org.apache.poi.xslf.usermodel.XSLFSlideShow;
import org.apache.poi.xssf.*;
import org.apache.poi.xssf.usermodel.XSSFSheet;
import org.apache.poi.xssf.usermodel.XSSFWorkbook;
import org.apache.poi.xwpf.usermodel.XWPFDocument;
import org.apache.poi.poifs.filesystem.*;

public class EmbeddedFiles {
	
	private final static Long MILLS_IN_DAY = 86400000L;
	public static void main(String[] args) throws Exception {
		
		/*//Passing the File Name To Read
        POIFSFileSystem fs = new POIFSFileSystem(new File("D://AMD PG&C//MDDS.xls"));
        //given a POI POIFSFileSystem object, and a specific directory within it, read in its Workbook and populate the high and low level models. If you're reading in a workbook
        HSSFWorkbook wb = new HSSFWorkbook(fs);
        // Loop in All EmbeddedObjects
        for (HSSFObjectData obj : wb.getAllEmbeddedObjects()) {
            String fileFormate = obj.getOLE2ClassName();
            if(obj.hasDirectoryEntry()){
                // The DirectoryEntry is a DocumentNode. Examine its entries to find out what it is
                DirectoryNode dn = (DirectoryNode) obj.getDirectory();
                for (Entry entry : dn) {
                    System.out.println(fileFormate + "." + entry.getName());
                }
            } else {
                // There is no DirectoryEntry
                // Recover the object's data from the HSSFObjectData instance.
                byte[] objectData = obj.getObjectData();
                System.out.println("**obj data***" +objectData);
            }
            if(fileFormate.contains("Packager Shell Object")){
            	DirectoryNode dn = (DirectoryNode) obj.getDirectory();
            	System.out.println(dn);
                System.out.println("File Name "+dn.getName()); 
                System.out.println("File Name "+dn.getEntryNames());
               
                InputStream is = dn.createDocumentInputStream(Ole10Native.OLE10_NATIVE);
                
                // Write it Using the FileOutputStream
               OutputStream fos = new FileOutputStream("D://AMD PG&C//abc.zip");
                System.out.println(obj.getDirectory().getName()+".zip");
                
               // Files.copy(is, fos,StandardCopyOption.REPLACE_EXISTING);
                IOUtils.copy(is, fos);
                fos.close();
                is.close();
                
                byte[] buf = new byte[8192];

		          //InputStream is = new FileInputStream(f);

		          int c = 0;

		          while ((c = is.read(buf, 0, buf.length)) > 0) {
		        	  fos.write(buf, 0, 8192);
		        	  fos.flush();
		          }
		          
		          fos.close();
		          System.out.println("stop");
		          is.close();
               
               
               // File file1=new File("D:/Users/subhardw/Desktop/test.zip");
                File file2=new File("D:/Users/subhardw/Desktop/test1.zip");
              Files.copy(is, file2.toPath(),StandardCopyOption.REPLACE_EXISTING);
              is.close();
                //Files.copy(file1.toPath(), file2.toPath(),StandardCopyOption.REPLACE_EXISTING);
           }
            
            if(fileFormate.contains("Acro")  ){
            	DirectoryNode dn = (DirectoryNode) obj.getDirectory();
            	System.out.println(dn);
                System.out.println("File Name "+dn.getName()); 
                System.out.println("File Name "+dn.getParent());
                System.out.println("File Name "+dn.getFileSystem());
                System.out.println("File Name "+dn.getEntryNames());
                
                InputStream is = dn.createDocumentInputStream("CONTENTS");
                
                // Write it Using the FileOutputStream
                FileOutputStream fos = new FileOutputStream("D://AMD PG&C//"+dn.getName()+".pdf");
                System.out.println(obj.getDirectory().getName()+".pdf");
                IOUtils.copy(is, fos);
                fos.close();
                is.close();
            }
        }
            DirectoryNode dn = (DirectoryNode)obj.getDirectory();
            Iterator<Entry> ab = dn.getEntries();
            System.out.println("entry "+ab);
            
           //Check the PDF name is Available in Excel
            if(fileFormate.contains("Acro") && dn.hasEntry("CONTENTS") ){
            	
                System.out.println("File Name "+dn.getName()); 
                System.out.println("File Name "+dn.getParent());
                System.out.println("File Name "+dn.getFileSystem());
                System.out.println("File Name "+dn.getEntryNames());
                
                InputStream is = dn.createDocumentInputStream("CONTENTS");
                
                // Write it Using the FileOutputStream
                FileOutputStream fos = new FileOutputStream("D://AMD PG&C//"+dn.getName()+".pdf");
                System.out.println(obj.getDirectory().getName()+".pdf");
                IOUtils.copy(is, fos);
                fos.close();
                is.close();
            }
            
            if(fileFormate.contains("Packager Shell Object") || fileFormate.contains(".zip")){

            	System.out.println("File Name "+dn.getName());
            	System.out.println("File Name "+dn.getStorageClsid());
            	
            	System.out.println("File Name "+obj.getContentType());
            	System.out.println("File Name "+dn.getEntryNames());
            	InputStream is = dn.createDocumentInputStream("Ole10Native");
                
                // Write it Using the FileOutputStream
                FileOutputStream fos = new FileOutputStream("D://AMD PG&C//"+dn.getName()+".zip");
                System.out.println(obj.getDirectory().getName()+".zip");
                
                IOUtils.copy(is, fos);
                fos.close();
                is.close();
                
             }
            
            if(fileFormate.contains("Worksheet")){

                InputStream is ;
                Entry entry = ab.next();
                is = dn.createDocumentInputStream(entry);
                FileOutputStream fos = new FileOutputStream("D://AMD PG&C//"+dn.getName()+".xlsx");
                IOUtils.copy(is, fos);
                fos.close();
                is.close();
             }
        }
        fs.close();
	}    */
		
		try{
		File excelFile = new File("D:/AMD PG&C/MDDS.xlsx");
		FileInputStream file = new FileInputStream(excelFile);
		XSSFWorkbook workbook = new XSSFWorkbook(file);
		XSSFSheet sheet=workbook.getSheetAt(0);
		  for (PackagePart pPart : workbook.getAllEmbedds()) {
			  
			  //System.out.println(pPart
		      String contentType = pPart.getContentType();
		      // Excel Workbook - either binary or OpenXML
		      if (contentType.equals("application/vnd.ms-excel")) {
		          HSSFWorkbook embeddedWorkbook = new HSSFWorkbook(pPart.getInputStream());
		      }
		      // Excel Workbook - OpenXML file format
		      else if (contentType.equals("application/vnd.openxmlformats-officedocument.spreadsheetml.sheet")) {
		          OPCPackage docPackage = OPCPackage.open(pPart.getInputStream());
		          XSSFWorkbook embeddedWorkbook = new XSSFWorkbook(docPackage);
		          System.out.println(embeddedWorkbook);
		          FileOutputStream outputstream= new FileOutputStream("D://AMD PG&C//test.xlsx");
		          embeddedWorkbook.write(outputstream);
		          System.out.println("created successfully");
		      }
		      // Word Document - binary (OLE2CDF) file format
		      else if (contentType.equals("application/msword")) {
		          HWPFDocument document = new HWPFDocument(pPart.getInputStream());
		      }
		      // Word Document - OpenXML file format
		      else if (contentType.equals("application/vnd.openxmlformats-officedocument.wordprocessingml.document")) {
		          OPCPackage docPackage = OPCPackage.open(pPart.getInputStream());
		          XWPFDocument document = new XWPFDocument(docPackage);
		      }
		      // PowerPoint Document - binary file format
		      
		      // Any other type of embedded object.
		      		      
		      else {
		          System.out.println("Unknown Embedded Document: " + contentType);
		          System.out.println("Unknown Embedded Document: " + pPart.getContentType() +pPart.getPartName());
		         //if(contentType.equals("Acro")){
		          InputStream is = pPart.getInputStream();
		          System.out.println(is);
		          
		          
		          
		          OutputStream oos = new FileOutputStream("D://AMD PG&C//test.*");
		          /*IOUtils.copy(is, oos);
		          oos.close();
	                is.close();*/

		        byte[] buf = new byte[4096];

		          //InputStream is = new FileInputStream(f);

		          int c = 0;

		          while ((c = is.read(buf, 0, buf.length)) > 0) {
		              oos.write(buf, 0, c);
		              oos.flush();
		          }
		          
		          oos.close();
		          System.out.println("stop");
		          is.close();
		          
		      }}

		          
		      
	        
		      
		  
		 
            
        }catch (Exception e) {
			e.printStackTrace();
		}
    }
}


